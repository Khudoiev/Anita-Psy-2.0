require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const path    = require('path');

const authRoutes          = require('./routes/auth');
const userSessionRoutes   = require('./routes/userSessions');
const invitesRoutes       = require('./routes/invites');
const sessionsRoutes      = require('./routes/sessions');
const chatRoutes          = require('./routes/chat');
const chatsRoutes         = require('./routes/chats');
const resetReqRoutes      = require('./routes/resetRequests');
const conversationsRoutes = require('./routes/conversations');

const app = express();
app.set('trust proxy', 1); // Trust first proxy (NGINX)

app.use(cors({
  origin: process.env.NODE_ENV === 'production' && process.env.FRONTEND_URL
    ? process.env.FRONTEND_URL : '*'
}));
app.use(express.json());

const checkBlacklistAndLimit = require('./middleware/checkBlacklist');

// Пропускаем admin/login и reset-request без rate-limit проверки
app.use('/api', (req, res, next) => {
  if (req.path === '/auth/admin/login') return next();
  if (req.path === '/auth/reset-request') return next();  // публичный endpoint
  checkBlacklistAndLimit(req, res, next);
});

// ── Routes ──────────────────────────────────────────────────
app.use('/api/auth',                 authRoutes);
app.use('/api/sessions',             userSessionRoutes);
app.use('/api/conversations',        conversationsRoutes);
app.use('/api/admin/invites',        invitesRoutes);
app.use('/api/admin/reset-requests', resetReqRoutes);
app.use('/api/admin',                sessionsRoutes);
app.use('/api/chat',                 chatRoutes);
app.use('/api',                      chatsRoutes);

try { require('./cron'); } catch (e) { console.warn('[Cron] Not loaded:', e.message); }

// ── Static ──────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, '../frontend')));
app.use('/admin', express.static(path.join(__dirname, '../admin')));

app.get('/admin*', (req, res) => {
  res.sendFile(path.join(__dirname, '../admin/index.html'));
});
app.get('*', (req, res) => {
  if (req.path.startsWith('/api')) return res.status(404).json({ error: 'Endpoint not found' });
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
